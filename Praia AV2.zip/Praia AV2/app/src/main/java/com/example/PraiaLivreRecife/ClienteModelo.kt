package com.example.PraiaLivreRecife

data class ClienteModelo(

   var  empId: String? = null,
   var NomeCliente: String? = null,
   var EmailCliente: String? = null,
   var SenhaCliente: String? = null
)
