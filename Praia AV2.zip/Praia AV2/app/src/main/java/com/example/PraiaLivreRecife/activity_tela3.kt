package com.example.PraiaLivreRecife

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.PraiaLivreRecife.databinding.ActivityTela3Binding

class activity_tela3 : AppCompatActivity() {
    private lateinit var binding: ActivityTela3Binding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_tela3)
        //oi
        //oi


    }
}