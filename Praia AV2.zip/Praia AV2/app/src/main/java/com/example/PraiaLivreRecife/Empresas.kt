package com.example.PraiaLivreRecife

data class Empresas(
    var empNome: String? = null
    var empEmpresa: String? = null
    var empSenha: String? = null
)
